library(shiny)
library(caret)
model2b = readRDS("model.rds")

# Define UI for machine learning model that predict cause 
ui <- fluidPage(
  
  # Application title
  titlePanel("predicting cause of escaped fish"),
  
  # Sidebar with inputs  
  sidebarLayout(
    sidebarPanel(
      selectInput("Season", "Select Season", c("Autumn", "Spring", "Winter", "Summer")),
      selectInput("Species", "Select Specie", c("Salmon", "Salmon.Fresh", "Salmon.Brood", "Other")),
      numericInput("Number", "Enter number of escaped fish", value = 0, min = 0, max = 500000, step = 1),
      numericInput("Cu", "Enter the Copper content", value = 0, min = -15, max = 15, step = 0.1),
      numericInput("N", "Enter the Nitrogen content", value = 0, min = 0, max = 1000, step = 0.1),
      numericInput("P", "Enter the Phosphorus content", value = 0, min = -150, max = 600, step = 1),
      actionButton("Go", "Predict")
      
    ),
    
    # Predict Cause of Fish Escapes
    mainPanel(
      tags$h3("Prediction for Cause of Fish Escape:"), 
      
      tags$p("Prediction for Cause based on the RF model is:"),
      textOutput("modelOutput"),
      
      tags$br(), # tags$br creates line break
      tags$br(), # tags$br creates line break
      tags$br(), # tags$br creates line break
      tags$a(href = "https://shiny.rstudio.com/", "See R Shiny docs for more") # tags$a creates a hyperlink
    )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  observeEvent(input$Go, {
    output$modelOutput <- renderPrint({
      se = input$Season
      sp = input$Species
      no = input$Number
      cu = input$Cu
      n = input$N
      p = input$P
      newData= data.frame(Season = se, Species = sp, Number = no, Cu = cu, N = n, P = p)
      
      prediction = predict(model2b, newData)
      print(prediction, max.level=0)
    })
  })
}

# Run the application 
shinyApp(ui = ui, server = server)